## intent:affirm
- yes\n

## intent:restaurant_search
- i'm looking for a place in the [n\north\n](location) of town

## synonym:chinese
- C\thi\rne\bs
- chines
- Chinese
