## story: Story with all different slot types
* card_lost
  - check_transactions
  - slot{"list_slot": ["value1", "value2"]}
  - slot{"bool_slot": true}
  - slot{"text_slot": "some_text"}
