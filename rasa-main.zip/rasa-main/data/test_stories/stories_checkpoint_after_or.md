## story with checkpoint after or
* affirm OR thank_you
> check_after_or

## story to continue checkpoint
> check_after_or
    - utter_default
* goodbye
    - utter_goodbye
