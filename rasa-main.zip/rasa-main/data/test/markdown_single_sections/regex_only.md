## regex:greet
- hey[^\s]*