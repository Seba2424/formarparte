## regex:greet
- hey[^\s]*

## synonym:animal

## lookup:chinese
- Chines
- Chinese