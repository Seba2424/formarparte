## synonym:animal

## entity:human
- person

## lookup:chinese
- Chines
- Chinese