Speed up the contradiction check of the [`RulePolicy`](policies.mdx#rule-policy)
by a factor of 3.
