import React from 'react';

const PrototyperContext = React.createContext();

export default PrototyperContext;
