import React from 'react';

// Add react-live imports you need here
const ReactLiveScope = {
  React,
  ...React,
};

export default ReactLiveScope;
